// PDF 용량 줄이기 — 페이지를 다시 그려 JPEG 로 굽습니다.
//
// pdf-lib 의 save() 는 이미지 스트림을 그대로 옮기기만 해서 용량이 줄지 않습니다.
// 스캔본은 용량의 대부분이 이미지라, 실제로 줄이려면 픽셀 수를 줄여야 합니다.
// 대신 글자 레이어가 사라집니다 (스캔본은 원래 없으므로 손해가 없습니다).

import { openForPreview } from './thumbs.js';

function canvasToJpeg(canvas, quality) {
  return new Promise((resolve, reject) => {
    canvas.toBlob(
      (blob) => (blob ? resolve(blob) : reject(new Error('JPEG 인코딩에 실패했습니다.'))),
      'image/jpeg',
      quality
    );
  });
}

/**
 * 페이지를 한 장씩 JPEG 로 구워 콜백에 넘깁니다. 한 장씩 넘기므로 메모리에 쌓이지 않습니다.
 * @param {(i:number, total:number, bytes:Uint8Array) => Promise<void>} onPage
 */
export async function forEachPageJpeg(bytes, scale, quality, onPage) {
  const src = await openForPreview(bytes.slice());
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d', { alpha: false });

  try {
    for (let i = 1; i <= src.numPages; i++) {
      const page = await src.getPage(i);
      const shot = page.getViewport({ scale });

      canvas.width = Math.max(1, Math.round(shot.width));
      canvas.height = Math.max(1, Math.round(shot.height));
      ctx.fillStyle = '#fff';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      await page.render({ canvasContext: ctx, viewport: shot }).promise;

      const blob = await canvasToJpeg(canvas, quality);
      await onPage(i, src.numPages, new Uint8Array(await blob.arrayBuffer()));
    }
  } finally {
    await src.destroy?.();
  }
}

/** 문서 전체를 scale 배율 · quality 화질로 다시 구워 새 PDF 바이트를 만듭니다 */
async function rasterize(bytes, scale, quality, onPage) {
  const { PDFDocument } = window.PDFLib;
  const src = await openForPreview(bytes.slice());
  const out = await PDFDocument.create();
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d', { alpha: false });

  try {
    for (let i = 1; i <= src.numPages; i++) {
      onPage?.(i, src.numPages);

      const page = await src.getPage(i);
      const paper = page.getViewport({ scale: 1 });   // 종이 크기 (포인트)
      const shot = page.getViewport({ scale });        // 그려낼 해상도

      canvas.width = Math.max(1, Math.round(shot.width));
      canvas.height = Math.max(1, Math.round(shot.height));
      ctx.fillStyle = '#fff';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      await page.render({ canvasContext: ctx, viewport: shot }).promise;

      const blob = await canvasToJpeg(canvas, quality);
      const img = await out.embedJpg(new Uint8Array(await blob.arrayBuffer()));
      const p = out.addPage([paper.width, paper.height]);
      p.drawImage(img, { x: 0, y: 0, width: paper.width, height: paper.height });
    }
  } finally {
    await src.destroy?.();
  }

  return out.save({ useObjectStreams: true });
}

/**
 * targetBytes 이하가 될 때까지 해상도와 화질을 낮춰가며 다시 굽습니다.
 * 최대 3번 시도하고, 못 맞추면 그중 가장 작은 결과를 돌려줍니다.
 * @returns {Promise<{bytes: Uint8Array, reached: boolean, dpi: number}>}
 */
export async function shrinkToTarget(bytes, targetBytes, onStatus) {
  let scale = 1.4;      // 72dpi 기준 배율 → 약 100dpi
  let quality = 0.72;
  let best = null;
  let bestDpi = 0;

  for (let attempt = 1; attempt <= 3; attempt++) {
    const dpi = Math.round(scale * 72);
    const result = await rasterize(bytes, scale, quality, (i, n) => {
      onStatus?.(`최적화 ${attempt}차 (${dpi}dpi) — ${i}/${n}쪽`);
    });

    if (!best || result.length < best.length) { best = result; bestDpi = dpi; }
    if (result.length <= targetBytes) return { bytes: result, reached: true, dpi };

    // 용량은 픽셀 수에 거의 비례합니다 → 배율은 제곱근만큼 줄입니다
    scale = Math.max(0.35, scale * Math.sqrt(targetBytes / result.length) * 0.92);
    quality = Math.max(0.4, quality - 0.12);
  }

  return { bytes: best, reached: false, dpi: bestDpi };
}
