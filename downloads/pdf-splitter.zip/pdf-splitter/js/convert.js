// 변환 탭 — 이미지↔PDF 변환

import * as U from './util.js';
import { openForPreview, renderPage } from './thumbs.js';

const $ = (id) => document.getElementById(id);

const state = {
  img2pdf: {
    files: [],     // File 객체 배열
    fileBlobs: [], // Uint8Array 배열
  },
  pdf2img: {
    file: null,
    bytes: null,
    pdfDoc: null,
    pageCount: 0,
    selectedPages: new Set(),
  },
};

export function initConvert() {
  // 탭 전환
  document.querySelectorAll('#panel-convert .modetab').forEach((btn) => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('#panel-convert .modetab').forEach((b) =>
        b.classList.toggle('is-active', b === btn)
      );
      document.querySelectorAll('#panel-convert .modebody').forEach((b) =>
        b.style.display = b.id === `convert${btn.dataset.convertMode === 'img2pdf' ? 'Img2pdf' : 'Pdf2img'}` ? 'flex' : 'none'
      );
    });
  });

  // 이미지 → PDF
  U.wireDrop($('img2pdfDrop'), $('img2pdfFile'), addImages, 'image');
  U.wireDrop($('img2pdfAddDrop'), $('img2pdfAddFile'), addImages, 'image');
  $('img2pdfClear').addEventListener('click', clearImages);
  $('btnImg2pdf').addEventListener('click', convertImg2pdf);

  // PDF → 이미지
  U.wireDrop($('pdf2imgDrop'), $('pdf2imgFile'), (files) => loadPdf(files[0]));
  $('pdf2imgReset').addEventListener('click', clearPdf);
  $('btnPdf2img').addEventListener('click', convertPdf2img);
  $('pdf2imgFormat').addEventListener('change', () => {
    $('pdf2imgQuality').disabled = $('pdf2imgFormat').value === 'png';
  });
}

// ── 이미지 → PDF ────────────────────────────

async function addImages(files) {
  const before = state.img2pdf.files.length;

  for (const file of files) {
    if (!U.imageKind(file)) {
      U.status(`${file.name}은(는) JPG/PNG가 아니라 건너뛰었습니다.`, 'err');
      continue;
    }
    const bytes = await U.readFile(file);
    state.img2pdf.files.push(file);
    state.img2pdf.fileBlobs.push(bytes);
  }

  if (!state.img2pdf.files.length) return;

  $('img2pdfDrop').hidden = true;
  $('img2pdfLoaded').hidden = false;

  drawImages();
  const added = state.img2pdf.files.length - before;
  U.status(
    before ? `${added}개 추가 — 이미지 ${state.img2pdf.files.length}개` : `${state.img2pdf.files.length}개 이미지 준비됨.`,
    'ok'
  );
}

function drawImages() {
  const box = $('img2pdfList');
  box.innerHTML = '';

  state.img2pdf.files.forEach((file, i) => {
    const item = document.createElement('div');
    item.className = 'thumb';
    item.style.padding = '8px';
    item.style.cursor = 'default';

    const preview = document.createElement('img');
    preview.style.cssText = 'width: 100%; height: 80px; object-fit: contain; background: #fff; border-radius: 4px;';
    preview.src = URL.createObjectURL(file);
    preview.addEventListener('load', () => URL.revokeObjectURL(preview.src), { once: true });

    const name = document.createElement('div');
    name.style.cssText = 'font-size: 11px; margin-top: 4px; text-align: center; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;';
    name.textContent = file.name;

    item.append(preview, name);
    box.appendChild(item);
  });
}

function clearImages() {
  state.img2pdf.files = [];
  state.img2pdf.fileBlobs = [];
  $('img2pdfDrop').hidden = false;
  $('img2pdfLoaded').hidden = true;
  U.status('이미지 목록을 비웠습니다.');
}

async function convertImg2pdf() {
  if (!state.img2pdf.files.length) return U.status('먼저 이미지를 선택하세요.', 'err');

  $('btnImg2pdf').disabled = true;
  try {
    const { PDFDocument } = window.PDFLib;
    const pdfDoc = await PDFDocument.create();

    for (let i = 0; i < state.img2pdf.fileBlobs.length; i++) {
      U.status(`이미지 변환 중… ${i + 1}/${state.img2pdf.fileBlobs.length}`);

      const imageBytes = state.img2pdf.fileBlobs[i];
      const file = state.img2pdf.files[i];
      const kind = U.imageKind(file);
      if (!kind) continue;

      const image = kind === 'png'
        ? await pdfDoc.embedPng(imageBytes)
        : await pdfDoc.embedJpg(imageBytes);

      const { width, height } = image.scaleToFit(595, 842); // A4 size
      const page = pdfDoc.addPage([595, 842]);
      page.drawImage(image, { x: (595 - width) / 2, y: (842 - height) / 2, width, height });
    }

    const name = U.safeName($('img2pdfName').value || '변환본');
    await U.saveBytes(await pdfDoc.save(), `${name}.pdf`);
    U.status(`${name}.pdf 로 변환했습니다.`, 'ok');
  } catch (e) {
    console.error(e);
    U.status(`변환 실패: ${e.message}`, 'err');
  } finally {
    $('btnImg2pdf').disabled = false;
  }
}

// ── PDF → 이미지 ────────────────────────────

async function loadPdf(file) {
  U.status(`${file.name} 여는 중…`);

  try {
    const bytes = await U.readFile(file);
    const pdfDoc = await openForPreview(bytes.slice());

    state.pdf2img.file = file;
    state.pdf2img.bytes = bytes;
    state.pdf2img.pdfDoc = pdfDoc;
    state.pdf2img.pageCount = pdfDoc.numPages;
    state.pdf2img.selectedPages.clear();

    // 기본값: 모든 페이지 선택
    for (let i = 0; i < pdfDoc.numPages; i++) {
      state.pdf2img.selectedPages.add(i);
    }

    $('pdf2imgDrop').hidden = true;
    $('pdf2imgLoaded').hidden = false;
    $('pdf2imgName').textContent = file.name;
    $('pdf2imgSaveName').value = U.stripExt(file.name);

    drawPdfPages();
    U.status(`${pdfDoc.numPages}쪽을 불러왔습니다.`, 'ok');
  } catch (e) {
    console.error(e);
    U.status('PDF를 열 수 없습니다.', 'err');
  }
}

function drawPdfPages() {
  const grid = $('pdf2imgThumbs');
  grid.innerHTML = '';

  for (let i = 0; i < state.pdf2img.pageCount; i++) {
    const thumb = document.createElement('div');
    thumb.className = 'thumb';
    thumb.dataset.index = String(i);
    thumb.style.cursor = 'pointer';

    const num = document.createElement('div');
    num.className = 'num';
    num.textContent = `${i + 1}`;

    const checkbox = document.createElement('div');
    checkbox.className = 'box';
    checkbox.style.cssText = 'position: absolute; top: 5px; left: 5px; width: 13px; height: 13px; border: 1px solid #B6C0CC; border-radius: 3px; background: #fff;';

    thumb.appendChild(checkbox);
    thumb.appendChild(num);

    thumb.addEventListener('click', () => {
      state.pdf2img.selectedPages.has(i) ? state.pdf2img.selectedPages.delete(i) : state.pdf2img.selectedPages.add(i);
      syncPdfChecks();
    });

    grid.appendChild(thumb);
  }

  syncPdfChecks();
}

function syncPdfChecks() {
  document.querySelectorAll('#pdf2imgThumbs .thumb').forEach((el) => {
    const idx = Number(el.dataset.index);
    const isChecked = state.pdf2img.selectedPages.has(idx);
    el.classList.toggle('checked', isChecked);
    el.querySelector('.box').style.cssText += isChecked
      ? 'background: var(--ink); border-color: var(--ink);'
      : 'background: #fff; border-color: #B6C0CC;';
  });
}

function clearPdf() {
  state.pdf2img.file = null;
  state.pdf2img.bytes = null;
  state.pdf2img.pdfDoc = null;
  state.pdf2img.pageCount = 0;
  state.pdf2img.selectedPages.clear();

  $('pdf2imgDrop').hidden = false;
  $('pdf2imgLoaded').hidden = true;
  U.status('파일을 불러오면 시작합니다.');
}

async function convertPdf2img() {
  if (!state.pdf2img.file || !state.pdf2img.selectedPages.size) {
    return U.status('먼저 PDF와 페이지를 선택하세요.', 'err');
  }

  $('btnPdf2img').disabled = true;
  $('pdf2imgReset').disabled = true;
  try {
    const format = $('pdf2imgFormat').value;
    const quality = Math.max(10, Math.min(100, parseInt($('pdf2imgQuality').value, 10) || 100));
    const pages = [...state.pdf2img.selectedPages].sort((a, b) => a - b);
    const pdfDoc = state.pdf2img.pdfDoc;
    const dpi = Number($('pdf2imgDpi').value);
    const baseName = U.safeName(($('pdf2imgSaveName').value.trim() || U.stripExt(state.pdf2img.file.name)).replace(/\.(png|jpe?g)$/i, ''));
    const ext = format === 'png' ? 'png' : 'jpg';

    for (let i = 0; i < pages.length; i++) {
      U.status(`이미지 변환 중… ${i + 1}/${pages.length}`);

      const pageNum = pages[i];
      const canvas = document.createElement('canvas');
      try {
        await renderPage(pdfDoc, pageNum + 1, canvas, 0, dpi);
        const blob = await new Promise((resolve, reject) => {
          canvas.toBlob(result => result ? resolve(result) : reject(new Error('이미지를 만들 수 없습니다. 해상도를 낮춰 주세요.')),
            format === 'png' ? 'image/png' : 'image/jpeg', quality / 100);
        });
        const bytes = new Uint8Array(await blob.arrayBuffer());
        const filename = pages.length === 1 ? baseName + '.' + ext : baseName + '_' + (pageNum + 1) + '.' + ext;
        await U.saveBytes(bytes, filename);
      } finally {
        canvas.width = 0;
        canvas.height = 0;
      }
    }

    U.status(`${pages.length}개 페이지를 이미지로 변환했습니다.`, 'ok');
  } catch (e) {
    console.error(e);
    U.status(`변환 실패: ${e.message}`, 'err');
  } finally {
    $('btnPdf2img').disabled = false;
    $('pdf2imgReset').disabled = false;
  }
}
