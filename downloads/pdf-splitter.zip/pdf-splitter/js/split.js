// 분할 탭 — 여러 PDF에서 뽑은 조각을 저장 목록에 쌓아두고 한 번에 저장

import * as U from './util.js';
import { openForPreview, renderPage, RenderQueue, makeThumb, attachCanvas } from './thumbs.js';

const $ = (id) => document.getElementById(id);

const state = {
  docs: new Map(),   // docId → {name, bytes, pageCount}
  cur: null,         // {docId, file, pdfDoc, pageCount} — 지금 미리보기 중인 문서
  checked: new Set(), // 원본 페이지 인덱스
  order: [],
  dragFrom: null,
  mode: 'range',
  cart: [],          // {docId, pages, label, name}
  activeRow: null,
  seq: 0,
  saving: false,
  selectedMonth: 7,  // 기본값 8월 (0-indexed)
  category: '',      // 분류명 (선택사항)
};

const queue = new RenderQueue();

export function initSplit() {
  U.wireDrop($('splitDrop'), $('splitFile'), (files) => load(files[0]));
  $('splitReset').addEventListener('click', closeCurrent);
  $('splitRefresh').addEventListener('click', refreshCurrent);
  $('removeChecked').addEventListener('click', removeCheckedPages);
  $('cartClear').addEventListener('click', clearCart);

  // 월 선택 버튼 생성
  const monthSelector = $('monthSelector');
  U.MONTHS.forEach((month, i) => {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'ghost sm';
    btn.textContent = month;
    btn.classList.toggle('is-active', i === state.selectedMonth);
    btn.addEventListener('click', () => {
      document.querySelectorAll('#monthSelector button').forEach((b) => b.classList.remove('is-active'));
      btn.classList.add('is-active');
      state.selectedMonth = i;
    });
    monthSelector.appendChild(btn);
  });

  // 분류 입력 필드
  $('categoryInput').addEventListener('input', (e) => {
    state.category = e.target.value.trim();
  });

  document.querySelectorAll('#panel-split .modetab').forEach((btn) => {
    btn.addEventListener('click', () => {
      state.mode = btn.dataset.mode;
      document.querySelectorAll('#panel-split .modetab').forEach((b) => b.classList.toggle('is-active', b === btn));
      document.querySelectorAll('#panel-split .modebody').forEach((b) =>
        b.classList.toggle('is-active', b.dataset.body === state.mode)
      );
    });
  });

  document.querySelectorAll('#panel-split [data-sel]').forEach((btn) => {
    btn.addEventListener('click', () => {
      if (!state.cur) return;
      const kind = btn.dataset.sel;
      state.checked.clear();
      for (let i = 0; i < state.order.length; i++) {
        if (kind === 'all') state.checked.add(state.order[i]);
        else if (kind === 'odd' && i % 2 === 0) state.checked.add(state.order[i]);
        else if (kind === 'even' && i % 2 === 1) state.checked.add(state.order[i]);
      }
      syncChecks();
    });
  });

  $('fillFromChecked').addEventListener('click', () => {
    if (!state.checked.size) return U.status('먼저 페이지를 체크하세요.', 'err');
    $('rangeInput').value = U.indicesToRangeText(state.order.flatMap((src, pos) => state.checked.has(src) ? [pos] : []));
    U.status(`${state.checked.size}쪽을 범위 칸에 넣었습니다.`);
  });

  $('btnBuild').addEventListener('click', addToCart);
  $('btnBuildEach').addEventListener('click', addEachToCart);
  $('btnSave').addEventListener('click', save);

  U.buildPresetBar($('presetBar'), applyPreset, true); // true = 분할용
  drawCart();
}

// ── 문서 불러오기 ─────────────────────────────

async function load(file) {
  queue.reset();
  state.checked.clear();
  U.status(`${file.name} 여는 중…`);

  let bytes, pdfDoc;
  try {
    bytes = await U.readFile(file);
    pdfDoc = await openForPreview(bytes.slice());
  } catch (e) {
    console.error(e);
    return U.status('이 파일을 열 수 없습니다. 손상되었거나 암호가 걸린 PDF일 수 있습니다.', 'err');
  }

  const docId = `d${++state.seq}`;
  state.docs.set(docId, { name: file.name, bytes, pageCount: pdfDoc.numPages });
  state.cur = { docId, file, pdfDoc, pageCount: pdfDoc.numPages };
  state.order = Array.from({ length: pdfDoc.numPages }, (_, i) => i);
  state.dragFrom = null;

  $('splitDrop').hidden = true;
  $('splitLoaded').hidden = false;
  $('splitName').textContent = file.name;
  $('splitMeta').textContent = `${pdfDoc.numPages}쪽 · ${U.formatBytes(file.size)}`;
  $('rangeInput').value = '';
  $('rangeInput').placeholder = `예: 1-3, 7, 10-${pdfDoc.numPages}`;

  drawThumbs();
  U.status(
    state.cart.length
      ? `${pdfDoc.numPages}쪽을 불러왔습니다. 담아둔 ${state.cart.length}개는 그대로 있습니다.`
      : `${pdfDoc.numPages}쪽을 불러왔습니다. 자를 방식을 고르세요.`,
    'ok'
  );
}

/** 미리보기만 닫습니다. 저장 목록은 유지됩니다. */
function closeCurrent() {
  queue.reset();
  state.cur = null;
  state.order = [];
  state.dragFrom = null;
  state.checked.clear();
  $('splitDrop').hidden = false;
  $('splitLoaded').hidden = true;
  $('splitThumbs').innerHTML = '';
  $('rangeInput').value = '';
  U.status(
    state.cart.length ? `다음 PDF를 불러오세요. 담아둔 ${state.cart.length}개는 그대로입니다.` : '파일을 불러오면 시작합니다.'
  );
}

function refreshCurrent() {
  if (!state.cur) return U.status('먼저 PDF를 불러오세요.', 'err');
  state.order = Array.from({ length: state.cur.pageCount }, (_, i) => i);
  state.checked.clear();
  state.dragFrom = null;
  $('rangeInput').value = '';
  drawThumbs();
  U.status(`전체 ${state.cur.pageCount}쪽을 복원했습니다. 저장 목록은 유지됩니다.`, 'ok');
}

function removeCheckedPages() {
  if (!state.cur) return U.status('먼저 PDF를 불러오세요.', 'err');
  if (!state.checked.size) return U.status('비울 페이지를 먼저 선택하세요.', 'err');
  const count = state.checked.size;
  state.order = state.order.filter((src) => !state.checked.has(src));
  state.checked.clear();
  $('rangeInput').value = '';
  drawThumbs();
  U.status(`${count}쪽을 작업영역에서 비웠습니다. 전체 새로고침으로 복원할 수 있습니다.`, 'ok');
}

function drawThumbs() {
  const grid = $('splitThumbs');
  grid.innerHTML = '';
  queue.reset();

  for (let pos = 0; pos < state.order.length; pos++) {
    const i = state.order[pos];
    const t = makeThumb(`${pos + 1} (원본 ${i + 1})`);
    t.el.draggable = true;
    t.el.title = "드래그하여 순서 변경";
    t.el.classList.toggle("checked", state.checked.has(i));
    t.el.addEventListener("dragstart", (e) => {
      state.dragFrom = pos;
      e.dataTransfer.effectAllowed = "move";
      e.dataTransfer.setData("text/plain", String(pos));
      t.el.classList.add("dragging");
    });
    t.el.addEventListener("dragend", () => {
      state.dragFrom = null;
      grid.querySelectorAll(".dragging, .dropbefore").forEach(el => el.classList.remove("dragging", "dropbefore"));
    });
    t.el.addEventListener("dragover", (e) => {
      if (state.dragFrom === null) return;
      e.preventDefault();
      e.dataTransfer.dropEffect = "move";
      grid.querySelectorAll(".dropbefore").forEach(el => el.classList.remove("dropbefore"));
      t.el.classList.add("dropbefore");
    });
    t.el.addEventListener("drop", (e) => {
      e.preventDefault();
      const from = state.dragFrom;
      if (from === null || from === pos) return;
      const [src] = state.order.splice(from, 1);
      state.order.splice(pos, 0, src);
      state.dragFrom = null;
      drawThumbs();
      U.status(`${from + 1}번을 ${pos + 1}번 자리로 옮겼습니다. 범위는 현재 순서 기준입니다.`);
    });
    t.el.dataset.index = String(i);
    t.el.addEventListener('click', () => {
      state.checked.has(i) ? state.checked.delete(i) : state.checked.add(i);
      syncChecks();
    });
    t.el.addEventListener('dblclick', async (e) => {
      e.stopPropagation();
      await openPageInNewTab(i);
    });
    grid.appendChild(t.el);

    const doc = state.cur.pdfDoc;
    queue.push(async () => {
      if (state.cur?.pdfDoc !== doc) return;
      const canvas = attachCanvas(t);
      await renderPage(doc, i + 1, canvas);
    });
  }
}

async function openPageInNewTab(pageIndex) {
  try {
    U.status(`페이지 ${pageIndex + 1} 열기 중…`);
    const { PDFDocument } = window.PDFLib;
    const srcDoc = await PDFDocument.load(state.docs.get(state.cur.docId).bytes.slice());
    const newDoc = await PDFDocument.create();
    const copiedPage = await newDoc.copyPages(srcDoc, [pageIndex]);
    copiedPage.forEach((p) => newDoc.addPage(p));

    const pdfBytes = await newDoc.save();
    const blob = new Blob([pdfBytes], { type: 'application/pdf' });
    const url = URL.createObjectURL(blob);

    window.open(url, '_blank');
    U.status(`페이지 ${pageIndex + 1}을 새 탭에서 열었습니다.`);

    setTimeout(() => URL.revokeObjectURL(url), 30000);
  } catch (e) {
    console.error(e);
    U.status(`페이지를 열 수 없습니다: ${e.message}`, 'err');
  }
}

function syncChecks() {
  document.querySelectorAll('#splitThumbs .thumb').forEach((el) => {
    el.classList.toggle('checked', state.checked.has(Number(el.dataset.index)));
  });
}

// ── 저장 목록 ─────────────────────────────

function addToCart() {
  if (!state.cur) return U.status('먼저 PDF를 불러오세요.', 'err');
  const { docId } = state.cur;
  const pageCount = state.order.length;
  if (!pageCount) return U.status('작업영역에 페이지가 없습니다. 전체 새로고침으로 복원하세요.', 'err');
  let groups = [];

  if (state.mode === 'range') {
    let rangeText = $('rangeInput').value.trim();
    // 범위 입력이 비어있으면 체크된 페이지 자동 사용
    if (!rangeText && state.checked.size > 0) {
      rangeText = U.indicesToRangeText(state.order.flatMap((src, pos) => state.checked.has(src) ? [pos] : []));
    }
    const { groups: g, error } = U.parseRanges(rangeText, pageCount);
    if (error) return U.status(error, 'err');
    groups = g;
  } else if (state.mode === 'every') {
    const n = Math.max(1, parseInt($('everyInput').value, 10) || 1);
    for (let s = 0; s < pageCount; s += n) {
      const e = Math.min(s + n, pageCount);
      const pages = [];
      for (let p = s; p < e; p++) pages.push(p);
      groups.push({ pages, label: s + 1 === e ? `${e}` : `${s + 1}-${e}` });
    }
  } else {
    for (let i = 0; i < pageCount; i++) groups.push({ pages: [i], label: `${i + 1}` });
  }

  const base = U.stripExt(state.docs.get(docId).name);
  const already = state.cart.filter((c) => c.docId === docId).length;
  groups.forEach((g, i) => {
    state.cart.push({ docId, pages: g.pages.map(pos => state.order[pos]), label: `원본 ${g.pages.map(pos => state.order[pos] + 1).join(" → ")}`, name: `${base}_${already + i + 1}` });
  });

  drawCart();
  U.status(`${groups.length}개를 담았습니다. 목록에 모두 ${state.cart.length}개.`, 'ok');
}

function addEachToCart() {
  if (!state.cur) return U.status('먼저 PDF를 불러오세요.', 'err');
  if (!state.order.length) return U.status('작업영역에 분리할 페이지가 없습니다. 전체 새로고침으로 복원하세요.', 'err');
  const docId = state.cur.docId;
  const base = U.stripExt(state.docs.get(docId).name);
  const already = state.cart.filter((c) => c.docId === docId).length;
  state.order.forEach((src, i) => {
    state.cart.push({ docId, pages: [src], label: `원본 ${src + 1}`, name: `${base}_${already + i + 1}` });
  });
  drawCart();
  U.status(`${state.order.length}개 낱장을 저장 목록에 담았습니다. 이름을 확인하고 전부 저장하세요.`, 'ok');
}

function drawCart() {
  const box = $('resultRows');
  box.innerHTML = '';
  $('resultCount').textContent = String(state.cart.length);
  $('cartEmpty').hidden = state.cart.length > 0;
  $('cartBody').hidden = state.cart.length === 0;

  state.cart.forEach((r, i) => {
    const row = document.createElement('div');
    row.className = 'row';

    const main = document.createElement('div');
    main.className = 'rowmain';

    const input = document.createElement('input');
    input.type = 'text';
    input.className = 'nameinput';
    input.value = r.name;
    input.spellcheck = false;
    input.addEventListener('input', () => { r.name = input.value; });
    input.addEventListener('focus', () => {
      state.activeRow = i;
      document.querySelectorAll('#resultRows .row').forEach((el, j) => el.classList.toggle('active', j === i));
    });

    const ext = document.createElement('span');
    ext.className = 'ext';
    ext.textContent = '.pdf';

    const del = document.createElement('button');
    del.type = 'button';
    del.className = 'del';
    del.title = '목록에서 빼기';
    del.textContent = '×';
    del.addEventListener('click', () => {
      state.cart.splice(i, 1);
      state.activeRow = null;
      drawCart();
      U.status(`목록에서 뺐습니다. 남은 ${state.cart.length}개.`);
    });

    main.append(input, ext, del);

    const meta = document.createElement('div');
    meta.className = 'rowmeta';
    const srcName = U.stripExt(state.docs.get(r.docId)?.name || '원본');
    meta.textContent = `${srcName} · ${r.label}쪽`;
    meta.title = meta.textContent;

    row.append(main, meta);
    box.appendChild(row);
  });

  $('btnSave').disabled = state.saving || state.cart.length === 0;
  $('btnSave').textContent = state.cart.length ? `${state.cart.length}개 전부 저장` : '전부 저장';
}

function applyPreset(label) {
  if (!state.cart.length) return U.status('먼저 저장 목록에 담으세요.', 'err');

  const month = U.MONTHS[state.selectedMonth];
  const parts = [month];
  if (state.category) parts.push(state.category);
  parts.push(label);
  const baseName = `${parts.join('_')}(${U.today()}분할)`;

  if ($('applyAll').checked) {
    state.cart.forEach((r, i) => { r.name = `${baseName}_${i + 1}`; });
    U.status(`${state.cart.length}줄 모두 적용했습니다.`, 'ok');
  } else {
    const i = state.activeRow ?? 0;
    state.cart[i].name = baseName;
    U.status(`${i + 1}번째 줄에 적용했습니다.`, 'ok');
  }
  drawCart();
  document.querySelectorAll('#resultRows .nameinput')[state.activeRow ?? 0]?.focus();
}

function clearCart() {
  if (!state.cart.length) return;
  state.cart = [];
  state.activeRow = null;
  drawCart();
  U.status('저장 목록을 비웠습니다.');
}

async function save() {
  if (!state.cart.length || state.saving) return;
  const batch = state.cart.map((r) => ({ ...r, pages: [...r.pages] }));
  state.saving = true;
  $('btnSave').disabled = true;

  try {
    const { PDFDocument } = window.PDFLib;
    const sources = new Map(); // docId → 로드된 PDFDocument (문서당 한 번만)
    const names = U.dedupeNames(batch.map((r) => U.safeName(r.name)));

    for (let i = 0; i < batch.length; i++) {
      const item = batch[i];
      U.status(`저장 중… ${i + 1}/${batch.length}`);

      if (!sources.has(item.docId)) {
        sources.set(item.docId, await PDFDocument.load(state.docs.get(item.docId).bytes.slice()));
      }
      const out = await PDFDocument.create();
      const copied = await out.copyPages(sources.get(item.docId), item.pages);
      copied.forEach((p) => out.addPage(p));
      await U.saveBytes(await out.save(), `${names[i]}.pdf`);
    }

    U.status(`${batch.length}개 파일을 다운로드 폴더에 저장했습니다.`, 'ok');
  } catch (e) {
    console.error(e);
    U.status(`저장하지 못했습니다: ${e.message}`, 'err');
  } finally {
    state.saving = false;
    $('btnSave').disabled = state.cart.length === 0;
  }
}
