// 툴바 아이콘을 누르면 기본으로 넓은 작업 탭을 엽니다.
chrome.action.onClicked.addListener(() => {
  chrome.tabs.create({ url: chrome.runtime.getURL('popup.html?full=1') });
});
