// 병합 탭 — 여러 PDF를 순서대로 하나로

import * as U from './util.js';
import { shrinkToTarget, forEachPageJpeg } from './optimize.js';

const $ = (id) => document.getElementById(id);
const TARGET = 4 * 1024 * 1024;
const A4 = { w: 595, h: 842 };
const JPG_SCALE = 2.0;    // 약 144dpi
const JPG_QUALITY = 0.88;

const items = []; // {file, bytes, pages, kind: 'pdf'|'png'|'jpeg'}
let lastMergedBytes = null; // 최적화 전 병합 결과 (다시 최적화할 때 원본으로 씁니다)
let outFormat = 'pdf';      // 'pdf' | 'jpg'

export function initMerge() {
  U.wireDrop($('mergeDrop'), $('mergeFile'), addFiles, 'pdf+image');
  U.wireDrop($('mergeAddDrop'), $('mergeAddFile'), addFiles, 'pdf+image');
  $('mergeClear').addEventListener('click', clearAll);
  buildFormatBar();
  $('btnMerge').addEventListener('click', merge);
  $('btnOptimizeResave').addEventListener('click', optimizeAndResave);
  U.buildPresetBar($('mergePresetBar'), (name) => {
    $('mergeName').value = name;
    $('mergeName').focus();
  });
}

function buildFormatBar() {
  const bar = $('mergeFormatBar');
  bar.innerHTML = '';
  const choices = [
    { key: 'pdf', label: 'PDF 한 개로', hint: '모두 합쳐 PDF 하나' },
    { key: 'jpg', label: 'JPG 낱장으로', hint: '합친 뒤 쪽마다 JPG 한 장' },
  ];
  for (const c of choices) {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'preset';
    b.textContent = c.label;
    b.title = c.hint;
    b.classList.toggle('is-active', c.key === outFormat);
    b.addEventListener('click', () => {
      outFormat = c.key;
      bar.querySelectorAll('.preset').forEach((x) => x.classList.remove('is-active'));
      b.classList.add('is-active');
      syncFormatUi();
      U.status(c.key === 'pdf' ? 'PDF 한 개로 저장합니다.' : '쪽마다 JPG 한 장으로 저장합니다.');
    });
    bar.appendChild(b);
  }
  syncFormatUi();
}

/** 형식에 따라 확장자 표시와 최적화 칸을 맞춥니다 */
function syncFormatUi() {
  const isPdf = outFormat === 'pdf';
  document.querySelector('#panel-merge .ext').textContent = isPdf ? '.pdf' : '_1.jpg, _2.jpg …';
  $('btnMerge').textContent = isPdf ? '합쳐서 저장' : '합쳐서 JPG로 저장';
  if (!isPdf) {
    $('mergeOptimizeBox').hidden = true;
    $('btnOptimizeResave').hidden = true;
  }
}

async function addFiles(files) {
  const { PDFDocument } = window.PDFLib;
  const before = items.length;

  for (const file of files) {
    try {
      const bytes = await U.readFile(file);
      const imgKind = U.imageKind(file);

      if (imgKind) {
        items.push({ file, bytes, pages: 1, kind: imgKind });
      } else {
        const doc = await PDFDocument.load(bytes.slice());
        items.push({ file, bytes, pages: doc.getPageCount(), kind: 'pdf' });
      }
    } catch (e) {
      console.error(e);
      U.status(`${file.name} 은(는) 열 수 없어 건너뛰었습니다.`, 'err');
    }
  }

  if (!items.length) return;

  $('mergeDrop').hidden = true;
  $('mergeLoaded').hidden = false;
  if (!$('mergeName').value) $('mergeName').value = `${U.stripExt(items[0].file.name)}_병합`;

  draw();
  const added = items.length - before;
  const total = `${items.length}개 파일 · 총 ${items.reduce((s, i) => s + i.pages, 0)}쪽`;
  U.status(before ? `${added}개 추가 — ${total}` : total, 'ok');
}

function draw() {
  const box = $('mergeList');
  box.innerHTML = '';

  items.forEach((it, i) => {
    const row = document.createElement('div');
    row.className = 'mergeitem';

    const idx = document.createElement('span');
    idx.className = 'idx';
    idx.textContent = String(i + 1);

    const name = document.createElement('span');
    name.className = 'mname';
    name.textContent = it.file.name;
    name.title = it.file.name;

    const meta = document.createElement('span');
    meta.className = 'mmeta';
    meta.textContent = it.kind === 'pdf' ? `${it.pages}쪽` : `이미지 · ${it.kind.toUpperCase()}`;

    const up = mini('↑', '위로', () => move(i, -1), i === 0);
    const down = mini('↓', '아래로', () => move(i, 1), i === items.length - 1);
    const del = mini('×', '빼기', () => { items.splice(i, 1); items.length ? draw() : clearAll(); });

    row.append(idx, name, meta, up, down, del);
    box.appendChild(row);
  });
}

function mini(label, title, onClick, disabled = false) {
  const b = document.createElement('button');
  b.type = 'button';
  b.className = 'ghost sm';
  b.textContent = label;
  b.title = title;
  b.disabled = disabled;
  if (disabled) b.style.opacity = '.35';
  else b.addEventListener('click', onClick);
  return b;
}

function move(i, dir) {
  const j = i + dir;
  if (j < 0 || j >= items.length) return;
  [items[i], items[j]] = [items[j], items[i]];
  draw();
}

/** 목록 순서대로 하나의 PDF 바이트를 만듭니다. 이미지는 페이지로 얹습니다. */
async function buildMerged() {
  const { PDFDocument } = window.PDFLib;
  const out = await PDFDocument.create();

  for (let i = 0; i < items.length; i++) {
    const it = items[i];
    U.status(`합치는 중… ${i + 1}/${items.length}`);

    if (it.kind === 'pdf') {
      const src = await PDFDocument.load(it.bytes.slice());
      const copied = await out.copyPages(src, src.getPageIndices());
      copied.forEach((p) => out.addPage(p));
      continue;
    }

    const img = it.kind === 'png'
      ? await out.embedPng(it.bytes)
      : await out.embedJpg(it.bytes);

    // A4 안에 들어가도록 줄이되, 여백 없이 그림 크기 그대로를 페이지로 씁니다
    const { width, height } = img.scaleToFit(A4.w, A4.h);
    const page = out.addPage([width, height]);
    page.drawImage(img, { x: 0, y: 0, width, height });
  }

  return out.save();
}

async function merge() {
  if (items.length < 2) return U.status('합치려면 파일이 2개 이상 필요합니다.', 'err');

  $('btnMerge').disabled = true;
  try {
    lastMergedBytes = await buildMerged();

    if (outFormat === 'jpg') {
      const name = U.safeName($('mergeName').value || '병합본');
      let saved = 0;
      await forEachPageJpeg(lastMergedBytes, JPG_SCALE, JPG_QUALITY, async (i, total, jpg) => {
        U.status(`JPG 로 굽는 중… ${i}/${total}쪽`);
        await U.saveBytes(jpg, `${name}_${i}.jpg`);
        saved = i;
      });
      U.status(`${name}_1.jpg … 총 ${saved}장을 저장했습니다.`, 'ok');
      return;
    }

    let final = lastMergedBytes;
    let tail = '';

    if ($('mergeOptimize').checked && final.length > TARGET) {
      const r = await shrinkToTarget(lastMergedBytes, TARGET, (m) => U.status(m));
      final = r.bytes;
      tail = r.reached ? ` (${r.dpi}dpi 로 줄임)` : ' — 4MB 까지는 줄이지 못했습니다';
    }

    showResultSize(final.length, lastMergedBytes.length);

    const name = U.safeName($('mergeName').value || '병합본');
    await U.saveBytes(final, `${name}.pdf`);
    U.status(`${name}.pdf 저장 · ${U.formatBytes(final.length)}${tail}`, tail.includes('못') ? 'err' : 'ok');
  } catch (e) {
    console.error(e);
    U.status(`합치지 못했습니다: ${e.message}`, 'err');
  } finally {
    $('btnMerge').disabled = false;
  }
}

function showResultSize(finalBytes, originalBytes) {
  const sizeDisplay = $('mergeResultSize');
  $('mergeOptimizeBox').hidden = false;

  const shrunk = finalBytes < originalBytes;
  let text = `결과: ${U.formatBytes(finalBytes)}`;
  if (shrunk) text += ` (원본 ${U.formatBytes(originalBytes)})`;

  const over = finalBytes > TARGET;
  if (over) {
    text += ' — 4MB 이상입니다';
    sizeDisplay.style.color = '#d32f2f';
  } else {
    text += ' ✓';
    sizeDisplay.style.color = '#2e7d32';
  }
  sizeDisplay.textContent = text;

  // 아직 4MB 를 넘고 최적화 여지가 남았을 때만 다시 굽기 버튼을 보입니다
  $('btnOptimizeResave').hidden = !(over && !shrunk);
}

async function optimizeAndResave() {
  if (!lastMergedBytes) return U.status('먼저 병합을 실행하세요.', 'err');

  $('btnOptimizeResave').disabled = true;
  try {
    const r = await shrinkToTarget(lastMergedBytes, TARGET, (m) => U.status(m));
    showResultSize(r.bytes.length, lastMergedBytes.length);

    const name = U.safeName($('mergeName').value || '병합본');
    await U.saveBytes(r.bytes, `${name}.pdf`);

    const tail = r.reached ? ` (${r.dpi}dpi 로 줄임)` : ' — 4MB 까지는 줄이지 못했습니다';
    U.status(`${name}.pdf 저장 · ${U.formatBytes(r.bytes.length)}${tail}`, r.reached ? 'ok' : 'err');
  } catch (e) {
    console.error(e);
    U.status(`최적화 실패: ${e.message}`, 'err');
  } finally {
    $('btnOptimizeResave').disabled = false;
  }
}

function clearAll() {
  items.length = 0;
  lastMergedBytes = null;
  $('mergeDrop').hidden = false;
  $('mergeLoaded').hidden = true;
  $('mergeList').innerHTML = '';
  $('mergeOptimizeBox').hidden = true;
  $('btnOptimizeResave').hidden = true;
  U.status('파일을 불러오면 시작합니다.');
}
