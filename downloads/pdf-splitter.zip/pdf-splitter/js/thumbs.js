// pdf.js 로 페이지 썸네일을 그립니다. 렌더링은 순차 처리하고,
// 파일이 바뀌면 이전 작업을 토큰으로 중단합니다.

import * as pdfjsLib from '../lib/pdf.min.mjs';

pdfjsLib.GlobalWorkerOptions.workerSrc = chrome.runtime.getURL('lib/pdf.worker.min.mjs');

const THUMB_WIDTH = 150; // 실제 픽셀 (표시는 CSS가 축소)

/** 미리보기용 문서 열기. bytes 는 복사본을 넘기세요 (pdf.js 가 버퍼를 가져갑니다) */
export async function openForPreview(bytes) {
  return pdfjsLib.getDocument({ data: bytes, isEvalSupported: false }).promise;
}

/** 한 페이지를 캔버스에 그립니다 */
export async function renderPage(pdfDoc, pageNumber, canvas, rotation = 0, dpi = null) {
  const page = await pdfDoc.getPage(pageNumber);
  const base = page.getViewport({ scale: 1, rotation: (page.rotate + rotation) % 360 });
  const scale = dpi === null ? THUMB_WIDTH / base.width : dpi / 72;
  const viewport = page.getViewport({ scale, rotation: (page.rotate + rotation) % 360 });

  if (dpi !== null && (viewport.width > 32767 || viewport.height > 32767 || viewport.width * viewport.height > 64000000)) {
    throw new Error("페이지가 너무 큽니다. 출력 해상도를 낮춰 주세요.");
  }
  canvas.width = Math.ceil(viewport.width);
  canvas.height = Math.ceil(viewport.height);
  const ctx = canvas.getContext('2d', { alpha: false });
  ctx.fillStyle = '#fff';
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  await page.render({ canvasContext: ctx, viewport }).promise;
}

/** 렌더 작업을 순서대로 처리하는 큐. token 이 바뀌면 남은 작업을 버립니다. */
export class RenderQueue {
  constructor() { this.token = 0; this.jobs = []; this.running = false; }

  reset() { this.token++; this.jobs = []; }

  push(job) {
    this.jobs.push({ job, token: this.token });
    if (!this.running) this.#run();
  }

  async #run() {
    this.running = true;
    while (this.jobs.length) {
      const { job, token } = this.jobs.shift();
      if (token !== this.token) continue;
      try { await job(); } catch (e) { console.warn('썸네일 렌더 실패:', e); }
    }
    this.running = false;
  }
}

/** 썸네일 카드 하나 만들기 (canvas 는 비어 있는 상태로 반환) */
export function makeThumb(labelText) {
  const el = document.createElement('div');
  el.className = 'thumb';

  const box = document.createElement('span');
  box.className = 'box';

  const ph = document.createElement('div');
  ph.className = 'ph';

  const num = document.createElement('span');
  num.className = 'num';
  num.textContent = labelText;

  el.append(box, ph, num);
  return { el, placeholder: ph, num };
}

/** 자리표시자를 실제 캔버스로 교체 */
export function attachCanvas(thumb) {
  const canvas = document.createElement('canvas');
  thumb.placeholder.replaceWith(canvas);
  thumb.placeholder = canvas;
  return canvas;
}
