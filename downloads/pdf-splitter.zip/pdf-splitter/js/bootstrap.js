// Keep startup failures visible even when an imported module cannot be parsed.
for (const type of ['dragover', 'drop']) {
  document.addEventListener(type, (event) => {
    if ([...(event.dataTransfer?.types || [])].includes('Files')) event.preventDefault();
  });
}
import('./popup.js').catch((error) => {
  console.error('PDF 분할기 시작 실패:', error);
  const status = document.getElementById('status');
  status.textContent = `시작 오류: ${error.message} — 확장 프로그램을 새로고침해 주세요.`;
  status.parentElement.classList.add('err');
});
