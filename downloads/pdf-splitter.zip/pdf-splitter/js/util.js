// 공용 유틸리티 — 날짜, 파일명, 페이지 범위 해석, 저장

export const PRESETS = ['교육여비신청서', '활동수당신청서', '교육여비기록부', '활동수당기록부'];

export const MONTHS = ['1월', '2월', '3월', '4월', '5월', '6월', '7월', '8월', '9월', '10월', '11월', '12월'];

/** 오늘 날짜를 YYYYMMDD 로 */
export function today() {
  const d = new Date();
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}`;
}

/** 프리셋 이름: 20260811_교육여비신청서 */
export function presetName(label) {
  return `${today()}_${label}`;
}

/** 월 + 프리셋으로 분할용 이름: 08월_교육여비신청서(20260813분할) */
export function splitPresetName(monthIndex, label) {
  const month = MONTHS[monthIndex] || '0월';
  return `${month}${label}(${today()}분할)`;
}

/** 윈도우에서 쓸 수 없는 문자 제거 */
export function safeName(name) {
  const cleaned = String(name || '')
    .replace(/[\\/:*?"<>|]/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .replace(/\.+$/, '');
  return cleaned || '무제';
}

/** 확장자 떼기 */
export function stripExt(filename) {
  return filename.replace(/\.pdf$/i, '');
}

export function formatBytes(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
}

/**
 * "1-3, 7, 10-12" → [{pages:[0,1,2], label:'1-3'}, ...]
 * 페이지 번호는 1부터, 반환 인덱스는 0부터.
 * @returns {{groups: Array, error: string|null}}
 */
export function parseRanges(text, pageCount) {
  const raw = String(text || '').trim();
  if (!raw) return { groups: [], error: '페이지 범위를 입력하세요.' };

  const groups = [];
  for (const chunk of raw.split(',')) {
    const part = chunk.trim();
    if (!part) continue;

    const m = part.match(/^(\d+)\s*(?:[-~]\s*(\d+))?$/);
    if (!m) return { groups: [], error: `"${part}" 은(는) 알아볼 수 없는 형식입니다.` };

    let start = parseInt(m[1], 10);
    let end = m[2] ? parseInt(m[2], 10) : start;
    if (start > end) [start, end] = [end, start];

    if (start < 1 || end > pageCount) {
      return { groups: [], error: `"${part}" 은(는) 범위를 벗어납니다. 이 문서는 1-${pageCount}쪽입니다.` };
    }

    const pages = [];
    for (let p = start; p <= end; p++) pages.push(p - 1);
    groups.push({ pages, label: start === end ? `${start}` : `${start}-${end}` });
  }

  if (!groups.length) return { groups: [], error: '페이지 범위를 입력하세요.' };
  return { groups, error: null };
}

/** 선택된 0-based 인덱스 배열 → "1-3, 7, 10-12" */
export function indicesToRangeText(indices) {
  const sorted = [...indices].sort((a, b) => a - b);
  const parts = [];
  let i = 0;
  while (i < sorted.length) {
    let j = i;
    while (j + 1 < sorted.length && sorted[j + 1] === sorted[j] + 1) j++;
    parts.push(i === j ? `${sorted[i] + 1}` : `${sorted[i] + 1}-${sorted[j] + 1}`);
    i = j + 1;
  }
  return parts.join(', ');
}

/** 같은 이름이 겹치면 _1, _2 를 붙여 유일하게 만듭니다 */
export function dedupeNames(names) {
  const seen = new Set();
  return names.map((n) => {
    let candidate = n;
    let suffix = 2;
    while (seen.has(candidate.toLowerCase())) candidate = `${n}_${suffix++}`;
    seen.add(candidate.toLowerCase());
    return candidate;
  });
}

/** Uint8Array 를 다운로드 폴더로 저장 */
export function saveBytes(bytes, filename) {
  return new Promise((resolve, reject) => {
    // 파일 확장자에 따라 MIME type 결정
    let mimeType = 'application/octet-stream';
    if (filename.endsWith('.pdf')) mimeType = 'application/pdf';
    else if (filename.endsWith('.xlsx')) mimeType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
    else if (filename.endsWith('.xls')) mimeType = 'application/vnd.ms-excel';
    else if (/\.jpe?g$/i.test(filename)) mimeType = 'image/jpeg';
    else if (filename.endsWith('.png')) mimeType = 'image/png';

    const blob = new Blob([bytes], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const done = (id) => {
      setTimeout(() => URL.revokeObjectURL(url), 20000);
      if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
      else resolve(id);
    };
    if (chrome?.downloads?.download) {
      chrome.downloads.download({ url, filename, saveAs: false, conflictAction: 'uniquify' }, done);
    } else {
      const a = document.createElement('a');
      a.href = url; a.download = filename;
      document.body.appendChild(a); a.click(); a.remove();
      done(null);
    }
  });
}

/** 파일 → Uint8Array */
export async function readFile(file) {
  const buf = await file.arrayBuffer();
  return new Uint8Array(buf);
}

/** 상태바 메시지 */
export function status(msg, kind = '') {
  const el = document.getElementById('status');
  if (!el) return;
  el.textContent = msg;
  el.parentElement.className = `statusbar ${kind}`;
}

/** PDF 인지 (드롭 시 type 이 비는 경우가 있어 확장자도 봅니다) */
export function isPdf(file) {
  return file.type === 'application/pdf' || /\.pdf$/i.test(file.name);
}

/** 이미지인지 — 'png' | 'jpeg' | null */
export function imageKind(file) {
  if (file.type === 'image/png' || /\.png$/i.test(file.name)) return 'png';
  if (file.type === 'image/jpeg' || /\.jpe?g$/i.test(file.name)) return 'jpeg';
  return null;
}

/** 파일 종류 판별 — kind: 'pdf' | 'image' | 'pdf+image' | 'all' */
function fileMatches(file, kind) {
  if (kind === 'all') return true;
  if (kind === 'image') return !!imageKind(file);
  if (kind === 'pdf+image') return isPdf(file) || !!imageKind(file);
  return isPdf(file);
}

/**
 * 드롭존 연결: 클릭·드래그·키보드
 * @param {'pdf'|'image'|'all'} kind 받아들일 파일 종류 (기본 pdf)
 */
export function wireDrop(dropEl, inputEl, onFiles, kind = 'pdf') {
  const pick = () => {
    try {
      if (typeof inputEl.showPicker === 'function') inputEl.showPicker();
      else inputEl.click();
    } catch {
      inputEl.click();
    }
  };
  dropEl.addEventListener('click', (e) => { if (e.target !== inputEl) pick(); });
  dropEl.querySelector('[data-pick-file]')?.addEventListener('click', (e) => { e.stopPropagation(); pick(); });
  dropEl.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); pick(); }
  });

  inputEl.addEventListener('change', () => {
    if (inputEl.files?.length) onFiles([...inputEl.files]);
    inputEl.value = '';
  });

  ['dragenter', 'dragover'].forEach((ev) =>
    dropEl.addEventListener(ev, (e) => { e.preventDefault(); dropEl.classList.add('over'); })
  );
  ['dragleave', 'drop'].forEach((ev) =>
    dropEl.addEventListener(ev, (e) => { e.preventDefault(); dropEl.classList.remove('over'); })
  );
  dropEl.addEventListener('drop', (e) => {
    const files = [...(e.dataTransfer?.files || [])].filter((f) => fileMatches(f, kind));
    if (files.length) onFiles(files);
    else if (kind === 'image') status('JPG 또는 PNG 파일만 넣을 수 있습니다.', 'err');
    else if (kind === 'pdf+image') status('PDF · JPG · PNG 만 넣을 수 있습니다.', 'err');
    else status('PDF 파일만 넣을 수 있습니다.', 'err');
  });
}

/** 프리셋 버튼 바 생성 (isForSplit=true면 분할용, false면 병합용) */
export function buildPresetBar(container, onPick, isForSplit = false) {
  container.innerHTML = '';
  for (const label of PRESETS) {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'preset';
    if (isForSplit) {
      b.textContent = label;
      b.addEventListener('click', () => onPick(label));
    } else {
      b.textContent = `${today()}_${label}`;
      b.addEventListener('click', () => onPick(presetName(label)));
    }
    container.appendChild(b);
  }
}
