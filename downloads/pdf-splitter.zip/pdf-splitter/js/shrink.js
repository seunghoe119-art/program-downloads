// 최적화 탭 — PDF 용량을 목표 크기 이하로 줄입니다. 파일마다 따로 저장합니다.

import * as U from './util.js';
import { shrinkToTarget } from './optimize.js';

const $ = (id) => document.getElementById(id);
const MB = 1024 * 1024;
const TARGETS = [4, 5, 6]; // MB

const items = [];        // {file, bytes}
let target = 4 * MB;

export function initShrink() {
  U.wireDrop($('shrinkDrop'), $('shrinkFile'), addFiles);
  U.wireDrop($('shrinkAddDrop'), $('shrinkAddFile'), addFiles);
  $('shrinkClear').addEventListener('click', clearAll);
  $('btnShrink').addEventListener('click', run);

  buildTargetBar();
}

function buildTargetBar() {
  const bar = $('shrinkTargets');
  bar.innerHTML = '';
  TARGETS.forEach((mb) => {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'preset';
    b.textContent = `${mb}MB`;
    b.classList.toggle('is-active', mb * MB === target);
    b.addEventListener('click', () => {
      target = mb * MB;
      bar.querySelectorAll('.preset').forEach((x) => x.classList.remove('is-active'));
      b.classList.add('is-active');
      U.status(`목표 용량을 ${mb}MB 로 정했습니다.`);
    });
    bar.appendChild(b);
  });
}

async function addFiles(files) {
  const before = items.length;

  for (const file of files) {
    try {
      const bytes = await U.readFile(file);
      items.push({ file, bytes });
    } catch (e) {
      console.error(e);
      U.status(`${file.name} 은(는) 열 수 없어 건너뛰었습니다.`, 'err');
    }
  }

  if (!items.length) return;

  $('shrinkDrop').hidden = true;
  $('shrinkLoaded').hidden = false;

  draw();
  const total = `${items.length}개 파일 · ${U.formatBytes(items.reduce((s, i) => s + i.bytes.length, 0))}`;
  U.status(before ? `${items.length - before}개 추가 — ${total}` : total, 'ok');
}

function draw() {
  const box = $('shrinkList');
  box.innerHTML = '';

  items.forEach((it, i) => {
    const row = document.createElement('div');
    row.className = 'mergeitem';

    const idx = document.createElement('span');
    idx.className = 'idx';
    idx.textContent = String(i + 1);

    const name = document.createElement('span');
    name.className = 'mname';
    name.textContent = it.file.name;
    name.title = it.file.name;

    const meta = document.createElement('span');
    meta.className = 'mmeta';
    meta.textContent = U.formatBytes(it.bytes.length);

    const del = document.createElement('button');
    del.type = 'button';
    del.className = 'ghost sm';
    del.textContent = '×';
    del.title = '빼기';
    del.addEventListener('click', () => {
      items.splice(i, 1);
      items.length ? draw() : clearAll();
    });

    row.append(idx, name, meta, del);
    box.appendChild(row);
  });
}

async function run() {
  if (!items.length) return U.status('먼저 PDF를 불러오세요.', 'err');

  $('btnShrink').disabled = true;
  const done = [];
  const missed = [];
  const skipped = [];

  try {
    for (let i = 0; i < items.length; i++) {
      const { file, bytes } = items[i];
      const head = `${i + 1}/${items.length} ${U.stripExt(file.name)}`;

      if (bytes.length <= target) {
        skipped.push(file.name);
        U.status(`${head} — 이미 작아서 건너뜁니다.`);
        continue;
      }

      const r = await shrinkToTarget(bytes, target, (m) => U.status(`${head} · ${m}`));
      const name = U.safeName(`${U.stripExt(file.name)}_저용량`);
      await U.saveBytes(r.bytes, `${name}.pdf`);

      (r.reached ? done : missed).push(`${file.name} → ${U.formatBytes(r.bytes.length)}`);
    }

    const parts = [];
    if (done.length) parts.push(`${done.length}개 성공`);
    if (missed.length) parts.push(`${missed.length}개는 목표 미달`);
    if (skipped.length) parts.push(`${skipped.length}개 건너뜀`);

    U.status(parts.join(' · ') || '처리할 파일이 없습니다.', missed.length ? 'err' : 'ok');
    if (missed.length) console.warn('목표 용량에 못 미친 파일:', missed);
  } catch (e) {
    console.error(e);
    U.status(`최적화 실패: ${e.message}`, 'err');
  } finally {
    $('btnShrink').disabled = false;
  }
}

function clearAll() {
  items.length = 0;
  $('shrinkDrop').hidden = false;
  $('shrinkLoaded').hidden = true;
  $('shrinkList').innerHTML = '';
  U.status('파일을 불러오면 시작합니다.');
}
