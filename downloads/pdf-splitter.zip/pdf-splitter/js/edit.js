// 편집 탭 — 페이지 회전 · 삭제 · 순서 변경

import * as U from './util.js';
import { openForPreview, renderPage, RenderQueue, makeThumb, attachCanvas } from './thumbs.js';

const $ = (id) => document.getElementById(id);
const queue = new RenderQueue();

const state = {
  file: null,
  bytes: null,
  pdfDoc: null,
  pages: [],        // {src: 원본 0-based 인덱스, rot: 0|90|180|270}
  checked: new Set(), // 현재 배열 위치 기준
  dragFrom: null,
};

export function initEdit() {
  U.wireDrop($('editDrop'), $('editFile'), (files) => load(files[0]));
  $('editReset').addEventListener('click', reset);
  $('editRotL').addEventListener('click', () => rotate(-90));
  $('editRotR').addEventListener('click', () => rotate(90));
  $('editDel').addEventListener('click', removeChecked);
  $('btnEditSave').addEventListener('click', save);
  U.buildPresetBar($('editPresetBar'), (name) => {
    $('editSaveName').value = name;
    $('editSaveName').focus();
  });
}

async function load(file) {
  reset();
  state.file = file;
  U.status(`${file.name} 여는 중…`);

  try {
    state.bytes = await U.readFile(file);
    state.pdfDoc = await openForPreview(state.bytes.slice());
    state.pages = Array.from({ length: state.pdfDoc.numPages }, (_, i) => ({ src: i, rot: 0 }));
  } catch (e) {
    console.error(e);
    return U.status('이 파일을 열 수 없습니다. 손상되었거나 암호가 걸린 PDF일 수 있습니다.', 'err');
  }

  $('editDrop').hidden = true;
  $('editLoaded').hidden = false;
  $('editName').textContent = file.name;
  $('editMeta').textContent = `${state.pages.length}쪽 · ${U.formatBytes(file.size)}`;
  $('editSaveName').value = `${U.stripExt(file.name)}_정리본`;

  draw();
  U.status('페이지를 끌어 옮기거나, 체크한 뒤 회전·삭제하세요.', 'ok');
}

function draw() {
  const grid = $('editThumbs');
  grid.innerHTML = '';
  queue.reset();

  state.pages.forEach((pg, pos) => {
    const t = makeThumb(String(pos + 1));
    t.el.dataset.pos = String(pos);
    t.el.draggable = true;
    t.el.classList.toggle('checked', state.checked.has(pos));
    if (pg.rot % 360 !== 0) t.el.classList.add('rot');
    t.el.title = `원본 ${pg.src + 1}쪽`;

    t.el.addEventListener('click', () => {
      state.checked.has(pos) ? state.checked.delete(pos) : state.checked.add(pos);
      t.el.classList.toggle('checked', state.checked.has(pos));
    });

    t.el.addEventListener('dragstart', (e) => {
      state.dragFrom = pos;
      t.el.classList.add('dragging');
      e.dataTransfer.effectAllowed = 'move';
      e.dataTransfer.setData('text/plain', String(pos));
    });
    t.el.addEventListener('dragend', () => {
      state.dragFrom = null;
      t.el.classList.remove('dragging');
      grid.querySelectorAll('.dropbefore').forEach((x) => x.classList.remove('dropbefore'));
    });
    t.el.addEventListener('dragover', (e) => {
      e.preventDefault();
      grid.querySelectorAll('.dropbefore').forEach((x) => x.classList.remove('dropbefore'));
      t.el.classList.add('dropbefore');
    });
    t.el.addEventListener('drop', (e) => {
      e.preventDefault();
      const from = state.dragFrom;
      if (from === null || from === pos) return;
      const [moved] = state.pages.splice(from, 1);
      state.pages.splice(pos, 0, moved);
      state.checked.clear();
      state.dragFrom = null;
      draw();
      U.status(`${from + 1}번 페이지를 ${pos + 1}번 자리로 옮겼습니다.`);
    });

    grid.appendChild(t.el);

    queue.push(async () => {
      const canvas = attachCanvas(t);
      await renderPage(state.pdfDoc, pg.src + 1, canvas, pg.rot);
    });
  });

  $('editMeta').textContent = `${state.pages.length}쪽 · ${U.formatBytes(state.file.size)}`;
}

function rotate(deg) {
  if (!state.checked.size) return U.status('회전할 페이지를 먼저 체크하세요.', 'err');
  for (const pos of state.checked) {
    state.pages[pos].rot = (((state.pages[pos].rot + deg) % 360) + 360) % 360;
  }
  const n = state.checked.size;
  draw();
  U.status(`${n}쪽을 ${deg > 0 ? '오른쪽' : '왼쪽'}으로 돌렸습니다.`, 'ok');
}

function removeChecked() {
  if (!state.checked.size) return U.status('삭제할 페이지를 먼저 체크하세요.', 'err');
  if (state.checked.size === state.pages.length) return U.status('모든 페이지를 지울 수는 없습니다.', 'err');

  const n = state.checked.size;
  state.pages = state.pages.filter((_, i) => !state.checked.has(i));
  state.checked.clear();
  draw();
  U.status(`${n}쪽을 뺐습니다. 남은 ${state.pages.length}쪽.`, 'ok');
}

async function save() {
  if (!state.pages.length) return;
  $('btnEditSave').disabled = true;

  try {
    const { PDFDocument, degrees } = window.PDFLib;
    const src = await PDFDocument.load(state.bytes.slice());
    const out = await PDFDocument.create();

    const copied = await out.copyPages(src, state.pages.map((p) => p.src));
    copied.forEach((page, i) => {
      const rot = state.pages[i].rot;
      if (rot) page.setRotation(degrees((page.getRotation().angle + rot) % 360));
      out.addPage(page);
    });

    const name = U.safeName($('editSaveName').value || '정리본');
    await U.saveBytes(await out.save(), `${name}.pdf`);
    U.status(`${name}.pdf (${state.pages.length}쪽) 를 저장했습니다.`, 'ok');
  } catch (e) {
    console.error(e);
    U.status(`저장하지 못했습니다: ${e.message}`, 'err');
  } finally {
    $('btnEditSave').disabled = false;
  }
}

function reset() {
  queue.reset();
  state.file = null;
  state.bytes = null;
  state.pdfDoc = null;
  state.pages = [];
  state.checked.clear();
  state.dragFrom = null;

  $('editDrop').hidden = false;
  $('editLoaded').hidden = true;
  $('editThumbs').innerHTML = '';
  U.status('파일을 불러오면 시작합니다.');
}
