// 진입점 — 탭 전환, 넓게 열기, 각 기능 초기화

import { initSplit } from './split.js';
import { initMerge } from './merge.js';
import { initEdit } from './edit.js';
import { initConvert } from './convert.js';
import { initShrink } from './shrink.js';
import { status, saveBytes } from './util.js';

// 같은 화면에서 크기만 바꿔 선택한 파일과 저장 목록을 유지합니다.
let isFull = new URLSearchParams(location.search).get('full') !== '0';
const expandButton = document.getElementById('btnExpand');
function updateView() {
  document.body.classList.toggle('full', isFull);
  document.body.classList.toggle('compact', !isFull);
  expandButton.textContent = isFull ? '짧게 보기' : '넓게 열기';
  expandButton.title = isFull ? '작은 화면으로 보기' : '넓은 화면으로 보기';
  expandButton.setAttribute('aria-expanded', String(isFull));
}
updateView();
expandButton.addEventListener('click', () => {
  isFull = !isFull;
  updateView();
  const url = new URL(location.href);
  url.searchParams.set('full', isFull ? '1' : '0');
  history.replaceState(null, '', url);
});

document.getElementById('btnDownloadTemplate').addEventListener('click', async () => {
  try {
    const response = await fetch(chrome.runtime.getURL('통합예시v2.xlsx'));
    const blob = await response.blob();
    await saveBytes(new Uint8Array(await blob.arrayBuffer()), '통합예시v2.xlsx');
    status('양식을 다운로드했습니다.', 'ok');
  } catch (e) {
    console.error(e);
    status(`다운로드 실패: ${e.message}`, 'err');
  }
});

document.querySelectorAll('.tab').forEach((tab) => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach((t) => t.classList.toggle('is-active', t === tab));
    document.querySelectorAll('.panel').forEach((p) =>
      p.classList.toggle('is-active', p.id === `panel-${tab.dataset.tab}`)
    );
  });
});

try {
  initSplit();
  initMerge();
  initEdit();
  initConvert();
  initShrink();
} catch (e) {
  console.error(e);
  status(`시작하지 못했습니다: ${e.message}`, 'err');
}
