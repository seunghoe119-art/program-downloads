FORM — iPhone Three.js 3D Studio (v2.0)
====================================

구성
- v2_iphone_threejs_studio.html : Three.js 실시간 360도 회전 3D 웹사이트
- v2_iphone_dual_blue.glb       : 독립된 고품질 3D 메시 파일 (48개 구성요소, 21,996 삼각형)
- v2_iphone_3d_preview.png      : GLB 모델의 앞면/뒷면 렌더링 미리보기

웹사이트 실행
1. 인터넷 연결이 된 Windows/Mac의 Chrome 또는 Edge 사용
2. v2_iphone_threejs_studio.html 파일을 더블 클릭
3. Three.js 라이브러리를 CDN에서 불러오면 모델이 표시됨

조작
- 마우스 왼쪽 드래그: 자유롭게 360도 돌리기
- 마우스 휠: 확대·축소
- 모바일: 손가락 터치 드래그 및 두 손가락 핀치
- FINISH: 4가지 색상
- CAMERA: 듀얼 / 프로 트리플 카메라
- ANGLE: 앞면 / 뒷면 / 측면 카메라 이동
- 자동 회전, 메시 와이어프레임 보기
- '3D 모델 저장 .GLB': 현재 웹사이트의 Three.js 모델을 GLB로 다운로드

GLB 파일 활용
- v2_iphone_dual_blue.glb는 Blender, Three.js, 3D 뷰어 등에 가져올 수 있음
- 웹사이트 HTML 자체도 Three.js 코드로 3D 메시를 생성하므로 GLB 파일 없이 사용 가능
- GLB 파일 안에 메시 재질과 전면 화면 텍스처가 포함됨

알림
- 이 3D 모델은 제품 사진을 바탕으로 정교하게 근사 제작한 창작 모델이며 공식 제조사 CAD 설계도는 아님
- 웹사이트 실행에는 CDN의 Three.js 다운로드를 위한 최초 인터넷 접속이 필요함
- 회사/기관 보안망에서 CDN이 차단되면 웹사이트가 작동하지 않을 수 있음
